$ErrorActionPreference = 'Stop'
$installDir = Join-Path $env:LOCALAPPDATA 'Programs\ClickerClub'
$startMenuDir = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Clicker Club'
$desktopShortcut = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Clicker Club.lnk'
$savePath = Join-Path $installDir 'clicker_save.json'
$saveBackup = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Clicker Club\clicker_save.json'

Get-Process -Name 'ClickerClub' -ErrorAction SilentlyContinue | Stop-Process -Force
if (Test-Path -LiteralPath $savePath) {
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $saveBackup) | Out-Null
    Move-Item -LiteralPath $savePath -Destination $saveBackup -Force
}
Remove-Item -LiteralPath $desktopShortcut -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $startMenuDir -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $installDir -Recurse -Force -ErrorAction SilentlyContinue
Write-Host 'Clicker Club was removed. Any save file was copied to Documents\Clicker Club.'
