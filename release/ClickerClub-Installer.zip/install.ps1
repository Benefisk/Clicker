$ErrorActionPreference = 'Stop'
$sourceDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$installDir = Join-Path $env:LOCALAPPDATA 'Programs\ClickerClub'
$startMenuDir = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Clicker Club'
$desktopShortcut = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Clicker Club.lnk'
$exePath = Join-Path $installDir 'ClickerClub.exe'

New-Item -ItemType Directory -Force -Path $installDir, $startMenuDir | Out-Null
Copy-Item -LiteralPath (Join-Path $sourceDir 'ClickerClub.exe') -Destination $exePath -Force
Copy-Item -LiteralPath (Join-Path $sourceDir 'icon.ico') -Destination (Join-Path $installDir 'icon.ico') -Force
Copy-Item -LiteralPath (Join-Path $sourceDir 'uninstall.ps1') -Destination $installDir -Force
Copy-Item -LiteralPath (Join-Path $sourceDir 'uninstall.cmd') -Destination $installDir -Force

$shell = New-Object -ComObject WScript.Shell
foreach ($shortcutPath in @($desktopShortcut, (Join-Path $startMenuDir 'Clicker Club.lnk'))) {
    $shortcut = $shell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = $exePath
    $shortcut.WorkingDirectory = $installDir
    $shortcut.IconLocation = (Join-Path $installDir 'icon.ico')
    $shortcut.Description = 'Clicker Club game'
    $shortcut.Save()
}

$uninstallShortcut = $shell.CreateShortcut((Join-Path $startMenuDir 'Uninstall Clicker Club.lnk'))
$uninstallShortcut.TargetPath = Join-Path $installDir 'uninstall.cmd'
$uninstallShortcut.WorkingDirectory = $installDir
$uninstallShortcut.IconLocation = "$env:SystemRoot\System32\shell32.dll,31"
$uninstallShortcut.Description = 'Uninstall Clicker Club'
$uninstallShortcut.Save()

Start-Process -FilePath $exePath -WorkingDirectory $installDir
Write-Host 'Clicker Club installed. Shortcuts were added to the desktop and Start menu.'
